# Calibre Enhancements add-on for NVDA
#This file is covered by the GNU General Public License.
#See the file COPYING.txt for more details.
#Copyright (C) 2018 Javi Dominguez <fjavids@gmail.com>

import appModuleHandler
import addonHandler
import api
import controlTypes
import ui
import globalCommands
import scriptHandler
from NVDAObjects.IAccessible import IAccessible, InaccessibleComboBox
import textInfos
from tones import beep
import os
import winUser
from speech import speakObject, pauseSpeech
from keyboardHandler import KeyboardInputGesture
from time import sleep
import re

addonHandler.initTranslation()

class AppModule(appModuleHandler.AppModule):

	#TRANSLATORS: category for Calibre input gestures
	scriptCategory = _("Calibre")

	def __init__(self, *args, **kwargs):
		super(AppModule, self).__init__(*args, **kwargs)
		self.lastBooksCount = []

	def chooseNVDAObjectOverlayClasses(self, obj, clsList):
		if obj.role == controlTypes.ROLE_TABLECOLUMNHEADER:
			if obj.location[2] == 0:
				obj.description = _("(hidden)")
			clsList.insert(0, EnhancedHeader)
		if obj.role == controlTypes.ROLE_EDITABLETEXT and obj.parent.role == controlTypes.ROLE_COMBOBOX and obj.previous.role == controlTypes.ROLE_LIST:
			obj.TextInfo  = obj.makeTextInfo(textInfos.POSITION_ALL)
			clsList.insert(0, ComboBox)
		if obj.role == controlTypes.ROLE_TABLECELL:
			clsList.insert(0, TableCell)
		try:
			if obj.role == controlTypes.ROLE_PANE and obj.IAccessibleRole == controlTypes.ROLE_MENUBAR and obj.parent.IAccessibleRole == 1050:
				clsList.insert(0, preferencesPane)
		except AttributeError:
			pass

	def event_gainFocus(self, obj, nextHandler):
		try:
			if obj.parent.firstChild == api.getForegroundObject().getChild(2).getChild(0).getChild(0) and obj.simpleNext.role == controlTypes.ROLE_BUTTON:
				obj.name = obj.simpleNext.name
		except:
			pass
		nextHandler()

	def event_focusEntered(self, obj, nextHandler):
		if obj.role != controlTypes.ROLE_SPLITBUTTON:
			nextHandler()

	def event_foreground(self, obj, nextHandler):
		try:
			self.lastBooksCount = self._getBooksCount().split(",")
		except:
			pass
		nextHandler()

	def event_nameChange(self, obj, nextHandler):
		if obj.role == controlTypes.ROLE_STATICTEXT and obj.parent.role == controlTypes.ROLE_STATUSBAR:
			try:
				booksCount = self._getBooksCount().split(",")
			except:
				pass
			else:
				if len(booksCount) == len(self.lastBooksCount):
					for i in range(0, len(booksCount)):
						if booksCount[i] != self.lastBooksCount[i]:
							ui.message(booksCount[i])
				else:
					ui.message(",".join(booksCount))
			self.lastBooksCount = booksCount
		nextHandler()

	def tbContextMenu(self, obj, func):
		api.setNavigatorObject(obj)
		x = obj.location[0]+2
		y = obj.location[1]+2
		winUser.setCursorPos(x, y)
		if api.getDesktopObject().objectFromPoint(x,y) == obj:
			scriptHandler.executeScript(func, None)
		else:
			ui.message(_("Not found"))

	def script_libraryMenu(self, gesture):
		fg = api.getForegroundObject()
		try:
			obj = fg.getChild(3).getChild(13)
		except AttributeError:
			ui.message(_("Not found"))
		else:
			ui.message("%s, %s" % (_("Tools bar"), obj.name))
			self.tbContextMenu(obj, globalCommands.commands.script_leftMouseClick)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_libraryMenu.__doc__ = _("open the context menu for selecting   and maintenance library")

	def script_addBooksMenu(self, gesture):
		fg = api.getForegroundObject()
		try:
			obj = fg.getChild(3).getChild(1)
		except AttributeError:
			ui.message(_("Not found"))
		else:
			ui.message("%s, %s" % (_("Tools bar"), obj.name))
			self.tbContextMenu(obj, globalCommands.commands.script_rightMouseClick)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_addBooksMenu.__doc__ = _("open the context menu for adding books")

	def script_searchMenu(self, gesture):
		fg = api.getForegroundObject()
		try:
			obj = fg.getChild(2).getChild(0).getChild(11)
		except AttributeError:
			ui.message(_("Not found"))
		else:
			ui.message("%s, %s" % (_("Search bar"), obj.name))
			self.tbContextMenu(obj, globalCommands.commands.script_rightMouseClick)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_searchMenu.__doc__ = _("open the context menu for saved searches")

	def script_virtualLibrary(self, gesture):
		fg = api.getForegroundObject()
		try:
			obj = fg.getChild(2).getChild(0).getChild(0)
		except AttributeError:
			ui.message(_("Not found"))
		else:
			ui.message("%s, %s" % (_("Search bar"), obj.name))
			self.tbContextMenu(obj, globalCommands.commands.script_leftMouseClick)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_virtualLibrary.__doc__ = _("open the context menu for virtual libraries")

	def script_navegateSearchBar(self, gesture):
		fg = api.getForegroundObject()
		obj = fg.getChild(2).getChild(0).getChild(0)
		if controlTypes.STATE_INVISIBLE in obj.states:
			ui.message(_("The search bar is not visible."))
		else:
			ui.message("%s, %s" % (_("Search bar"), obj.name))
			api.setNavigatorObject(obj)
			scriptHandler.executeScript(globalCommands.commands.script_moveMouseToNavigatorObject, None)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_navegateSearchBar.__doc__ = _("bring the objects navigator to first item on search bar")

	def script_navegateToolsBar(self, gesture):
		ui.message(_("Tools bar"))
		fg = api.getForegroundObject()
		obj = fg.getChild(3).getChild(0)
		speakObject(obj)
		api.setNavigatorObject(obj)
		scriptHandler.executeScript(globalCommands.commands.script_moveMouseToNavigatorObject, None)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_navegateToolsBar.__doc__ = _("bring the objects navigator to first item on toolbar")

	def script_booksCount(self, gesture):
		ui.message(self._getBooksCount())
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_booksCount.__doc__ = _("says the total of books in the current library view and the number of books selected")

	def _getBooksCount(self):
		fg = api.getForegroundObject()
		try:
			statusBar = filter(lambda o: o.role == controlTypes.ROLE_STATUSBAR, fg.children)[0]
		except IndexError:
			raise Exception("Filter has failed; statusBar not found")
		obj = statusBar.firstChild
		while obj:
			try:
				if re.match(".*[Cc]alibre.*Kovid\sGoyal.*\[", obj.name):
					break
			except TypeError:
				pass
			obj = obj.next
		try:
			return re.search("\[[^\[\]]*[0,].*\]", obj.name).group()[1:-1]
		except AttributeError:
			raise Exception("The search expression is not found in the status bar")

	def script_navegateHeaders(self, gesture):
		fg = api.getForegroundObject()
		obj = fg.getChild(2).getChild(2).getChild(1).getChild(0).getChild(0).getChild(1).getChild(1).getChild(0).getChild(2)
		api.setNavigatorObject(obj)
		scriptHandler.executeScript(globalCommands.commands.script_moveMouseToNavigatorObject, None)
		ui.message(obj.name)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_navegateHeaders.__doc__ = _("bring the objects navigator to first item on table header")

	__gestures = {
	"kb:F8": "libraryMenu",
	"kb:F7": "addBooksMenu",
	"kb:F6": "searchMenu",
	"kb:F5": "virtualLibrary",
	"kb:F9": "navegateSearchBar",
	"kb:F10": "navegateToolsBar",
	"kb:NVDA+H": "navegateHeaders",
	"kb:NVDA+End": "booksCount"
	}

class EnhancedHeader(IAccessible):
	pass

class ComboBox(InaccessibleComboBox):

	def event_caret (self):
		try:
			savedSearches = [o.name for o in self.previous.children]
			if self.TextInfo.text not in savedSearches:
				caret = self.TextInfo ._getCaretOffset()
				if caret == len(self.TextInfo .text):
					caret = caret-1
				if caret < 0:
					caret = 0
				ui.message(self.TextInfo .text[caret])
		except IndexError:
			pass

class TableCell(IAccessible):

	#TRANSLATORS: category for Calibre input gestures
	scriptCategory = _("Calibre")

	def event_gainFocus(self):
		if winUser.getKeyState(KeyboardInputGesture.fromName("Control").vkCode) in (0,1):
			try:
				self.states.remove(controlTypes.STATE_SELECTED)
			except KeyError:
				pass
		if not self.name:
			self.name = " "
		# TRANSLATORS: Name of the columns Title and Author as shown in the interface of Calibre 
		if self.columnHeaderText.lower() != _("Title").lower() and self.columnHeaderText.lower()  != _("Author(s)").lower():
			ui.message(self.columnHeaderText)
		speakObject(self, controlTypes.REASON_CARET)

	def script_headerOptions(self, gesture):
		obj = self.parent.getChild(1)
		while obj.name != self.columnHeaderText and obj.role == controlTypes.ROLE_TABLECOLUMNHEADER:
			obj = obj.next
		obj.scrollIntoView()
		api.setNavigatorObject(obj)
		speakObject(obj)
		winUser.setCursorPos(obj.location[0], obj.location[1]+5)
		if obj.location[0] > winUser.getCursorPos()[0] or controlTypes.STATE_INVISIBLE in obj.states:
			ui.message(_("Out of screen, can't click"))
			beep(300, 90)
		else:
			winUser.mouse_event(winUser.MOUSEEVENTF_RIGHTDOWN,0,0,None,None)
			winUser.mouse_event(winUser.MOUSEEVENTF_RIGHTUP,0,0,None,None)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_headerOptions.__doc__ = _("open the context menu for settings of the current column")

	def script_bookInfo(self, gesture):
		if api.getForegroundObject().role == controlTypes.ROLE_DIALOG:
			gesture.send()
			return
		# TRANSLATORS: Name of the column Title as shown in the interface of Calibre 
		title = self.getDataFromColumn(_("Title"))
		ui.message(title)
		try:
			clipboard = api.getClipData()
		except TypeError: # Specified clipboard format is not available
			clipboard = ""
		gesture.send()
		KeyboardInputGesture.fromName("tab").send() # Skip to document
		KeyboardInputGesture.fromName("applications").send() # Open context menu
		KeyboardInputGesture.fromName("t").send() # Copy to clipboard
		KeyboardInputGesture.fromName("escape").send() # Close dialog
		# sleep(0.50)
		if scriptHandler.getLastScriptRepeatCount() == 1:
			ui.browseableMessage(api.getClipData(), title if title else _("Book info"))
		else:
			sleep(0.50)
			ui.message(api.getClipData())
		if not api.copyToClip(clipboard):
			api.win32clipboard.OpenClipboard()
			api.win32clipboard.EmptyClipboard()
			api.win32clipboard.CloseClipboard()

	def script_searchBookInTheWeb(self, gesture):
		# TRANSLATORS: Put the domain corresponding to your country
		domain = _("google.com")
		# TRANSLATORS: Name of the column Title as shown in the interface of Calibre
		title = self.getDataFromColumn(_("Title"))
		# TRANSLATORS: Name of the column Author as shown in the interface of Calibre 
		author = self.getDataFromColumn(_("Author(s)"))
		url = u'https://www.%s/search?tbm=bks&q=intitle:%s+inauthor:%s' % (domain, title, author)
		os.startfile(url)
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_searchBookInTheWeb.__doc__ = _("search the current book in Google")

	def getDataFromColumn(self, columnName):
		if self.columnHeaderText.lower() == columnName.lower():
			return self.name
		obj = self.previous
		while obj.role == controlTypes.ROLE_TABLECELL:
			if obj.columnHeaderText.lower() == columnName.lower():
				return obj.name
			obj = obj.previous
		obj = self.next
		while obj.role == controlTypes.ROLE_TABLECELL:
			if obj.columnHeaderText.lower() == columnName.lower():
				return obj.name
			obj = obj.next
		return ""

	__gestures = {
	"kb:NVDA+Control+H": "headerOptions",
	"kb:I": "bookInfo",
	"kb:F12": "searchBookInTheWeb"
	}

class preferencesPane(IAccessible):
	tabItems = []
	focusedWidget = None

	def __updateTab(self, index):
		if self.focusedWidget:
			return
		fg = api.getForegroundObject()
		max = len(self.tabItems)-1
		index = 0 if index > max else max if index < 0 else index
		setattr(fg, "tabIndex", index)
		self.name = self.tabItems[fg.tabIndex].name
		speakObject(self)

	def event_gainFocus(self):
		try:
			self.tabItems = filter(lambda i: i.IAccessibleRole == controlTypes.ROLE_HEADING1 and i.next.IAccessibleRole == controlTypes.ROLE_TAB, self.recursiveDescendants)
		except AttributeError:
			pass
		if self.tabItems:
			self.role = controlTypes.ROLE_TAB
			fg = api.getForegroundObject()
			if not hasattr(fg, "tabIndex"):
				setattr(fg, "tabIndex", 0)
			self.__updateTab(fg.tabIndex)
		else:
			try:
				if self.simpleFirstChild.IAccessibleRole == controlTypes.ROLE_HEADING1:
					self.name = self.simpleFirstChild.name
			except AttributeError:
				Pass
			speakObject(self)

	def __skipToTab(self, skip):
		if not self.tabItems:
			gesture.send()
			return
		fg = api.getForegroundObject()
		self.__updateTab(fg.tabIndex+skip)

	def script_nextTab(self, gesture):
		self.__skipToTab(+1)

	def script_previousTab(self, gesture):
		self.__skipToTab(-1)

	def script_nextTab_(self, gesture):
		self.focusedWidget = None
		self.__skipToTab(+1)

	def script_previousTab_(self, gesture):
		self.focusedWidget = None
		self.__skipToTab(-1)

	def script_nextWidget(self, gesture):
		if not self.tabItems:
			gesture.send()
			return
		fg = api.getForegroundObject()
		if not self.focusedWidget:
			self.focusedWidget = self.tabItems[fg.tabIndex].next.simpleFirstChild
		else:
			self.focusedWidget = self.focusedWidget.simpleNext
		if self.focusedWidget:
			api.setNavigatorObject(self.focusedWidget)
			speakObject(self.focusedWidget)
		else:
			gesture.send()

	def script_previousWidget(self, gesture):
		if not self.focusedWidget:
			gesture.send()
			return
		self.focusedWidget = self.focusedWidget.simplePrevious
		if self.focusedWidget:
			api.setNavigatorObject(self.focusedWidget)
			speakObject(self.focusedWidget)
		else:
			api.setNavigatorObject(self)
			speakObject(self)

	def script_doAction(self, gesture):
		if self.focusedWidget:
			self.focusedWidget.doAction()

	__gestures = {
	"kb:rightArrow": "nextTab",
	"kb:leftArrow": "previousTab",
	"kb:Tab": "nextWidget",
	"kb:Shift+Tab": "previousWidget",
	"kb:Control+Tab": "nextTab_",
	"kb:Shift+Control+Tab": "previousTab_",
	"kb:downArrow": "nextWidget",
	"kb:upArrow": "previousWidget",
	"kb:Enter": "doAction",
	"kb:Space": "doAction"
	}