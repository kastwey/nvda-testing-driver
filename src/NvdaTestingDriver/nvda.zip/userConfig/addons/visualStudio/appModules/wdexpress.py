# appModule for visual studio
#author: mohammad suliman (mohmad.s93@gmail.com)
#This file is covered by the GNU General Public License.
#See the file COPYING for more details.
#Copyright (C) 2016 Mohammad Suliman

#this app module is for visual studio express, we use the same exact module of the community edition (devenv.py)
from devenv import *